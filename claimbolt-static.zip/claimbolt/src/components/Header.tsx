"use client";

import { useEffect, useState } from "react";

const LINKS = [
  { href: "#practices", label: "For practices" },
  { href: "#estimator", label: "Estimate recovery" },
  { href: "#deadline", label: "Check a deadline" },
  { href: "#faq", label: "Questions" },
];

export function Bolt() {
  return (
    <svg viewBox="0 0 18 22" aria-hidden="true">
      <path d="M11 0 0 13h7l-2 9L18 8h-7l2-8z" fill="#2448D8" />
    </svg>
  );
}

export default function Header() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="top">
      <div className="wrap">
        <div className="top-bar">
          <a className="logo" href="#top" aria-label="ClaimBolt home">
            <Bolt />
            ClaimBolt
          </a>
          <nav className="nav" aria-label="Main">
            {LINKS.map((l) => (
              <a key={l.href} className="nav-link" href={l.href}>
                {l.label}
              </a>
            ))}
            <button
              type="button"
              className="menu-btn"
              aria-expanded={open}
              aria-controls="mobile-nav"
              onClick={() => setOpen((o) => !o)}
            >
              {open ? "Close" : "Menu"}
            </button>
            <a className="btn" href="#start">
              Free review
            </a>
          </nav>
        </div>
        <nav id="mobile-nav" className="mobile-nav" data-open={open} aria-label="Mobile">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}>
              {l.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
