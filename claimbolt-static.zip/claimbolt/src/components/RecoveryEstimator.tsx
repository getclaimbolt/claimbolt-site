"use client";

import { useId, useState } from "react";
import StartButton from "@/components/StartButton";
import { CONTINGENCY_RATE, DESK_APPEAL_CAP, DESK_PRICE, money, roughMoney } from "@/lib/pricing";

type RangeProps = {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  hint?: React.ReactNode;
  onChange: (v: number) => void;
};

function Range({ label, value, min, max, step, display, hint, onChange }: RangeProps) {
  const id = useId();
  const fill = `${((value - min) / (max - min)) * 100}%`;
  return (
    <div className="range">
      <div className="range-head">
        <label htmlFor={id}>{label}</label>
        <output className="range-value" htmlFor={id}>{display}</output>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-valuetext={display}
        style={{ "--fill": fill } as React.CSSProperties}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      {hint && <p className="range-hint">{hint}</p>}
    </div>
  );
}

const WIN_RATES = [
  { value: 35, label: "Cautious", note: "35%" },
  { value: 50, label: "Typical", note: "50%" },
  { value: 65, label: "Strong", note: "65%" },
];

export default function RecoveryEstimator() {
  const [billed, setBilled] = useState(60000);
  const [denialRate, setDenialRate] = useState(12);
  const [unworkedShare, setUnworkedShare] = useState(50);
  const [winRate, setWinRate] = useState(50);
  const [avgClaim, setAvgClaim] = useState(300);
  const claimId = useId();

  const denied = (billed * denialRate) / 100;
  const unworked = (denied * unworkedShare) / 100;
  const recovered = (unworked * winRate) / 100;
  const fee = recovered * CONTINGENCY_RATE;
  const keepRecovery = recovered - fee;
  const appeals = avgClaim > 0 ? Math.ceil(unworked / avgClaim) : 0;
  const deskFits = appeals <= DESK_APPEAL_CAP;
  const keepDesk = recovered - DESK_PRICE;

  let best: "recovery" | "desk" = "recovery";
  let verdict: string;
  if (!deskFits) {
    verdict = `That’s about ${appeals} appeals a month, more than one desk covers. Recovery works at any volume, or we can quote a larger desk.`;
  } else if (fee > DESK_PRICE) {
    best = "desk";
    verdict = `The appeals desk saves you about ${roughMoney(fee - DESK_PRICE)} a month at this volume.`;
  } else {
    verdict = `Recovery costs less at this volume: you only pay when claims are paid.`;
  }

  const rows = [
    { label: "Denied each month", value: denied, color: "var(--rule)" },
    { label: "Never appealed today", value: unworked, color: "var(--pen-mid)" },
    { label: "Likely won on appeal", value: recovered, color: "var(--pen)" },
    { label: `Yours after our ${CONTINGENCY_RATE * 100}%`, value: keepRecovery, color: "var(--pen-dark)" },
  ];

  const summary = `Billed ${money(billed)}/mo, ${denialRate}% denied, ${unworkedShare}% never appealed, avg claim ${money(avgClaim)}, ${winRate}% win rate: est. ${roughMoney(recovered)}/mo recovered, ~${appeals} appeals/mo`;

  return (
    <div className="tool">
      <div className="tool-inputs">
        <Range
          label="Billed to insurance each month"
          value={billed}
          min={10000}
          max={500000}
          step={5000}
          display={money(billed)}
          onChange={setBilled}
        />
        <Range
          label="Share of claims denied"
          value={denialRate}
          min={3}
          max={30}
          step={1}
          display={`${denialRate}%`}
          hint={<>The average initial denial rate is about 11.8% (<a href="https://qualigenix.com/claim-denials-2026/" target="_blank" rel="noopener">Qualigenix, 2026</a>).</>}
          onChange={setDenialRate}
        />
        <Range
          label="Denials your team never gets to"
          value={unworkedShare}
          min={10}
          max={100}
          step={5}
          display={`${unworkedShare}%`}
          hint="Written off, past timely filing, or sitting in a queue."
          onChange={setUnworkedShare}
        />
        <div className="field">
          <label htmlFor={claimId}>Typical denied claim</label>
          <div className="money-input">
            <span aria-hidden="true">$</span>
            <input
              id={claimId}
              type="number"
              inputMode="numeric"
              min={25}
              max={50000}
              step={25}
              value={avgClaim}
              onChange={(e) => setAvgClaim(Math.max(0, Number(e.target.value)))}
            />
          </div>
          <p className="hint">Used to count how many appeals that is each month.</p>
        </div>
        <fieldset className="segmented" style={{ "--cols": 3 } as React.CSSProperties}>
          <legend>Appeal win rate to assume</legend>
          {WIN_RATES.map((r) => (
            <label key={r.value}>
              <input
                type="radio"
                name="win-rate"
                value={r.value}
                checked={winRate === r.value}
                onChange={() => setWinRate(r.value)}
              />
              <span>
                {r.label}
                <small>{r.note}</small>
              </span>
            </label>
          ))}
        </fieldset>
        <p className="range-hint">
          In New York, almost 53% of appealed denials were overturned in 2025 (
          <a href="https://www.healthcaredive.com/news/insurance-denials-overturned-appeal-new-york-study-JAMA/817490/" target="_blank" rel="noopener">JAMA study</a>
          ). Results vary by payer and denial type.
        </p>
      </div>

      <div className="tool-output" aria-live="polite">
        <p className="hero-figure">You could recover about</p>
        <p className="hero-number">
          {roughMoney(recovered)}
          <span style={{ fontSize: "0.4em", letterSpacing: 0, fontWeight: 700 }}> /month</span>
        </p>
        <p className="hero-sub">That’s roughly {roughMoney(recovered * 12)} a year that’s currently written off.</p>

        <ul className="flow" aria-label="Where the money goes each month">
          {rows.map((r) => (
            <li key={r.label}>
              <span className="flow-label">{r.label}</span>
              <span className="flow-value">{roughMoney(r.value)}</span>
              <div className="flow-track" aria-hidden="true">
                <div className="flow-bar" style={{ width: `${denied ? (r.value / denied) * 100 : 0}%`, background: r.color }} />
              </div>
            </li>
          ))}
        </ul>

        <div className="compare">
          <div className="plan-card" data-best={best === "recovery"}>
            <h4>
              Recovery {best === "recovery" && <span className="tag">Best fit</span>}
            </h4>
            <p className="cost">{roughMoney(fee)}/mo</p>
            <p>You keep {roughMoney(keepRecovery)}. Pay only on paid claims.</p>
          </div>
          <div className="plan-card" data-best={best === "desk"}>
            <h4>
              Appeals desk {best === "desk" && <span className="tag">Best fit</span>}
            </h4>
            <p className="cost">{money(DESK_PRICE)}/mo</p>
            <p>
              {deskFits
                ? keepDesk > 0
                  ? `You keep ${roughMoney(keepDesk)}. Covers your ~${appeals} appeals.`
                  : `Costs more than you’d likely recover at this volume.`
                : `Covers ${DESK_APPEAL_CAP} of your ~${appeals} appeals.`}
            </p>
          </div>
        </div>

        <p className="verdict">{verdict}</p>
        <StartButton audience="practice" prefill={{ estimate: summary }}>
          Get a free backlog review
        </StartButton>
        <p className="tool-foot">A rough estimate to size the opportunity, not a promise of results.</p>
      </div>
    </div>
  );
}
