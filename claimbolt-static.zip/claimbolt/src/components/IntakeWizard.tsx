"use client";

import { useEffect, useRef, useState } from "react";
import { PLAN_RULES } from "@/lib/deadlines";
import { START_EVENT, type Audience, type StartDetail } from "@/lib/startIntake";

type Field = {
  name: string;
  label: string;
  kind: "text" | "email" | "tel" | "select" | "textarea" | "date";
  required?: boolean;
  options?: string[];
  placeholder?: string;
  hint?: string;
  autoComplete?: string;
  half?: boolean;
  missing?: string;
};

type Step = { title: string; short: string; fields: Field[]; warn?: string };

const CONTACT: Step = {
  title: "How should we reach you?",
  short: "Contact",
  fields: [
    { name: "name", label: "Your name", kind: "text", required: true, autoComplete: "name", half: true },
    { name: "email", label: "Email", kind: "email", required: true, autoComplete: "email", half: true },
    { name: "phone", label: "Phone (optional)", kind: "tel", autoComplete: "tel", half: true },
  ],
};

const STEPS: Record<Audience, Step[]> = {
  practice: [
    {
      title: "Tell us about your practice",
      short: "Practice",
      warn: "Please don’t include patient names or records. We’ll send a secure link after the BAA is signed.",
      fields: [
        { name: "practice", label: "Practice name", kind: "text", required: true, autoComplete: "organization" },
        {
          name: "specialty",
          label: "Specialty",
          kind: "select",
          required: true,
          options: [
            "ABA / autism services",
            "Behavioral health / therapy",
            "Substance use treatment",
            "Home health",
            "Specialty medical practice",
            "Other",
          ],
        },
        { name: "payers", label: "Main payers (optional)", kind: "text", placeholder: "For example: Aetna, Fidelis, UnitedHealthcare" },
      ],
    },
    {
      title: "What do your denials look like?",
      short: "Denials",
      fields: [
        {
          name: "backlog",
          label: "Open denials, roughly",
          kind: "select",
          required: true,
          half: true,
          options: ["Under $10,000", "$10,000 – $50,000", "$50,000 – $250,000", "Over $250,000", "Not sure"],
        },
        {
          name: "monthly",
          label: "New denials a month",
          kind: "select",
          required: true,
          half: true,
          options: ["Under 10", "10 – 25", "26 – 50", "Over 50", "Not sure"],
        },
        {
          name: "notes",
          label: "Anything else? (optional)",
          kind: "textarea",
          placeholder: "Common denial reasons, who handles appeals today, timely filing worries",
        },
      ],
    },
    CONTACT,
  ],
  patient: [
    {
      title: "Tell us about the denial",
      short: "Denial",
      fields: [
        {
          name: "denied",
          label: "What was denied?",
          kind: "select",
          required: true,
          options: [
            "ABA / autism therapy",
            "Mental health or substance use treatment",
            "Specialty drug or prescription",
            "Surgery, imaging or procedure",
            "Home health",
            "Surprise out-of-network bill",
            "Something else",
          ],
        },
        {
          name: "amount",
          label: "Amount at stake",
          kind: "select",
          required: true,
          half: true,
          options: ["Under $2,000", "$2,000 – $10,000", "$10,000 – $50,000", "Over $50,000", "Not sure"],
        },
        { name: "plan", label: "Plan type", kind: "select", half: true, options: PLAN_RULES.map((p) => p.label) },
        { name: "deadline", label: "Appeal deadline, if you know it", kind: "date", half: true },
      ],
    },
    {
      title: "What happened?",
      short: "Details",
      warn: "Keep it short and leave out diagnoses and medical records. If we can help, we’ll email you a secure way to send the denial letter.",
      fields: [
        {
          name: "story",
          label: "In a sentence or two",
          kind: "textarea",
          required: true,
          missing: "Tell us briefly what happened.",
          placeholder: "For example: Insurer stopped covering my son’s ABA therapy in August, saying it’s not medically necessary.",
        },
      ],
    },
    CONTACT,
  ],
};

// Formspree form URL, baked in at build time (see README). Formspree endpoints are public by design.
const FORM_ENDPOINT = process.env.NEXT_PUBLIC_FORMSPREE_ENDPOINT ?? "";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

type Status = "idle" | "sending" | "done" | "error";

export default function IntakeWizard() {
  const [audience, setAudience] = useState<Audience>("practice");
  const [step, setStep] = useState(0);
  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");
  const titleRef = useRef<HTMLHeadingElement>(null);
  const moved = useRef(false);

  const steps = STEPS[audience];
  const current = steps[step];
  const last = step === steps.length - 1;

  // Other parts of the page (estimator, deadline checker, offer buttons) open the form through this event.
  useEffect(() => {
    const onStart = (e: Event) => {
      const { audience: a, prefill } = (e as CustomEvent<StartDetail>).detail;
      setAudience(a);
      setStep(0);
      setErrors({});
      setStatus("idle");
      setValues((v) => ({ ...v, ...prefill }));
      moved.current = true;
    };
    window.addEventListener(START_EVENT, onStart);
    return () => window.removeEventListener(START_EVENT, onStart);
  }, []);

  useEffect(() => {
    if (moved.current) {
      titleRef.current?.focus({ preventScroll: true });
      moved.current = false;
    }
  }, [step, audience, status]);

  function set(name: string, value: string) {
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: "" }));
  }

  function validate(s: Step): boolean {
    const next: Record<string, string> = {};
    for (const f of s.fields) {
      const v = (values[f.name] ?? "").trim();
      if (f.required && !v) next[f.name] = f.missing ?? (f.kind === "select" ? "Choose an option." : `Add ${f.label.toLowerCase()}.`);
      else if (f.kind === "email" && v && !EMAIL_RE.test(v)) next[f.name] = "Check the email address, for example name@example.com.";
    }
    setErrors(next);
    const firstBad = s.fields.find((f) => next[f.name]);
    if (firstBad) document.getElementById(`f-${firstBad.name}`)?.focus();
    return !firstBad;
  }

  function switchAudience(a: Audience) {
    if (a === audience) return;
    setAudience(a);
    setStep(0);
    setErrors({});
    setStatus("idle");
  }

  function goNext() {
    if (!validate(current)) return;
    moved.current = true;
    setStep((s) => s + 1);
  }

  function goBack() {
    moved.current = true;
    setErrors({});
    setStep((s) => s - 1);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!last) return goNext();
    if (!validate(current)) return;

    const names = new Set(steps.flatMap((s) => s.fields.map((f) => f.name)));
    const body = new FormData();
    body.append("_subject", audience === "practice" ? "ClaimBolt: practice backlog review" : "ClaimBolt: patient case review");
    body.append("type", audience === "practice" ? "Practice backlog review" : "Patient case review");
    for (const n of names) {
      if (values[n]) body.append(n, values[n].trim());
    }
    if (audience === "practice" && values.estimate) body.append("estimate", values.estimate);
    body.append("_gotcha", values.website ?? ""); // Formspree's spam trap

    if (!FORM_ENDPOINT) {
      setStatus("error");
      setMessage("The form isn’t switched on yet. Please email appeals@getclaimbolt.com and we’ll reply within one business day.");
      return;
    }

    setStatus("sending");
    setMessage("");
    try {
      const res = await fetch(FORM_ENDPOINT, { method: "POST", body, headers: { Accept: "application/json" } });
      if (res.ok) {
        moved.current = true;
        setStatus("done");
        return;
      }
      const data = (await res.json().catch(() => ({}))) as { errors?: { message?: string }[] };
      setStatus("error");
      setMessage(
        data.errors?.[0]?.message
          ? `That didn’t go through: ${data.errors[0].message}. Try again, or email appeals@getclaimbolt.com.`
          : "That didn’t go through. Try again, or email appeals@getclaimbolt.com."
      );
    } catch {
      setStatus("error");
      setMessage("That didn’t go through. Check your connection and try again, or email appeals@getclaimbolt.com.");
    }
  }

  function reset() {
    setValues({});
    setStep(0);
    setStatus("idle");
    moved.current = true;
  }

  if (status === "done") {
    return (
      <div className="form-card done" role="status">
        <svg viewBox="0 0 44 44" aria-hidden="true">
          <circle cx="22" cy="22" r="21" fill="#E3F3EA" />
          <path d="m13 22.5 6 6 12-13" stroke="#1D6B42" strokeWidth="3.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <h3 ref={titleRef} tabIndex={-1} className="step-title">Got it. We’ll be in touch within one business day.</h3>
        <ol>
          {audience === "practice" ? (
            <>
              <li>We email you a Business Associate Agreement to sign.</li>
              <li>You send up to 20 denials through a secure link.</li>
              <li>We tell you which are worth fighting and what they’re likely worth.</li>
            </>
          ) : (
            <>
              <li>We read what you sent and tell you honestly whether we can help.</li>
              <li>If we can, we explain which option fits and send you a secure way to share your denial letter.</li>
              <li>Nothing is charged until you agree to go ahead.</li>
            </>
          )}
        </ol>
        <button type="button" className="linkish" onClick={reset}>Send another</button>
      </div>
    );
  }

  const carried = step === 0 && audience === "practice" ? values.estimate : undefined;

  return (
    <div className="form-card">
      <div className="tabs" role="tablist" aria-label="Who is this for">
        {(["practice", "patient"] as const).map((a) => (
          <button
            key={a}
            type="button"
            role="tab"
            aria-selected={audience === a}
            aria-controls="intake-form"
            onClick={() => switchAudience(a)}
          >
            {a === "practice" ? "I run a practice" : "I’m a patient"}
          </button>
        ))}
      </div>

      <ol className="progress" aria-label="Progress">
        {steps.map((s, i) => (
          <li key={s.short} data-state={i < step ? "done" : i === step ? "current" : "todo"} aria-current={i === step ? "step" : undefined}>
            {s.short}
          </li>
        ))}
      </ol>

      <form id="intake-form" onSubmit={submit} noValidate>
        <h3 ref={titleRef} tabIndex={-1} className="step-title">
          <span className="visually-hidden">Step {step + 1} of {steps.length}: </span>
          {current.title}
        </h3>

        {current.warn && <p className="warn">{current.warn}</p>}
        {carried && (
          <p className="carried">
            <b>Your estimate will be included:</b> {carried}
          </p>
        )}

        <div className="grid2">
          {current.fields.map((f) => {
            const id = `f-${f.name}`;
            const err = errors[f.name];
            const describedBy = err ? `${id}-err` : f.hint ? `${id}-hint` : undefined;
            const common = {
              id,
              name: f.name,
              "aria-invalid": err ? true : undefined,
              "aria-describedby": describedBy,
              required: f.required,
            };
            return (
              <div className="field" key={f.name} style={f.half ? undefined : { gridColumn: "1 / -1" }}>
                <label htmlFor={id}>{f.label}</label>
                {f.kind === "select" ? (
                  <select {...common} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)}>
                    <option value="">Choose one</option>
                    {f.options!.map((o) => (
                      <option key={o}>{o}</option>
                    ))}
                  </select>
                ) : f.kind === "textarea" ? (
                  <textarea {...common} placeholder={f.placeholder} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} />
                ) : (
                  <input
                    {...common}
                    type={f.kind}
                    autoComplete={f.autoComplete}
                    placeholder={f.placeholder}
                    value={values[f.name] ?? ""}
                    onChange={(e) => set(f.name, e.target.value)}
                  />
                )}
                {err ? (
                  <p className="error" id={`${id}-err`}>{err}</p>
                ) : (
                  f.hint && <p className="hint" id={`${id}-hint`}>{f.hint}</p>
                )}
              </div>
            );
          })}
        </div>

        <div className="hp" aria-hidden="true">
          <label htmlFor="f-website">Website</label>
          <input id="f-website" tabIndex={-1} autoComplete="off" value={values.website ?? ""} onChange={(e) => set("website", e.target.value)} />
        </div>

        <div className="wizard-nav">
          {step > 0 && (
            <button type="button" className="btn ghost" onClick={goBack}>
              Back
            </button>
          )}
          <button type="submit" className="btn" disabled={status === "sending"}>
            {last ? (status === "sending" ? "Sending…" : "Request free review") : "Next"}
          </button>
        </div>
        <p className={`form-status${status === "error" ? " err" : ""}`} role="status" aria-live="polite">
          {status === "error" ? message : ""}
        </p>
      </form>
    </div>
  );
}
