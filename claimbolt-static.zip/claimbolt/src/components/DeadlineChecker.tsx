"use client";

import { useId, useState, useSyncExternalStore } from "react";
import StartButton from "@/components/StartButton";
import {
  PLAN_RULES,
  computeDeadline,
  formatLongDate,
  parseLocalDate,
  toIsoDate,
  type PlanId,
} from "@/lib/deadlines";
import {
  CONTINGENCY_RATE,
  LETTER_PRICE,
  PATIENT_CONTINGENCY_MIN,
  amountBucket,
  money,
} from "@/lib/pricing";

const noopSubscribe = () => () => {};

type Level = "ok" | "soon" | "urgent" | "past";

function levelFor(daysLeft: number): Level {
  if (daysLeft < 0) return "past";
  if (daysLeft <= 14) return "urgent";
  if (daysLeft <= 30) return "soon";
  return "ok";
}

const LEVEL_TEXT: Record<Level, string> = {
  ok: "You have time, but don’t wait",
  soon: "Start this week",
  urgent: "Act now",
  past: "The standard window has passed",
};

function LevelIcon({ level }: { level: Level }) {
  if (level === "ok") {
    return (
      <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="currentColor" /><path d="m4.8 8.2 2.1 2.1 4.3-4.6" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
    );
  }
  if (level === "soon") {
    return (
      <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="currentColor" /><path d="M8 4.2V8l2.4 1.6" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" /></svg>
    );
  }
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.2 15.2 14H.8L8 1.2Z" fill="currentColor" /><path d="M8 6v3.6" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" /><circle cx="8" cy="11.8" r="1" fill="#fff" /></svg>
  );
}

export default function DeadlineChecker() {
  const [plan, setPlan] = useState<PlanId>("employer");
  const [letterDate, setLetterDate] = useState("");
  const [amountText, setAmountText] = useState("");
  // Today is only known in the browser; the server snapshot is empty, which avoids a hydration mismatch.
  const todayIso = useSyncExternalStore(noopSubscribe, () => toIsoDate(new Date()), () => "");
  const today = todayIso ? parseLocalDate(todayIso) : null;
  const dateId = useId();
  const amountId = useId();

  const rule = PLAN_RULES.find((r) => r.id === plan)!;
  const parsed = parseLocalDate(letterDate);
  const amount = Number(amountText.replace(/[^0-9.]/g, "")) || 0;
  const maxDate = today ? toIsoDate(today) : undefined;
  const futureDate = parsed && today && parsed > today;
  const result = parsed && today && !futureDate ? computeDeadline(parsed, rule.days, today) : null;
  const level = result ? levelFor(result.daysLeft) : null;
  const contingency = amount >= PATIENT_CONTINGENCY_MIN;

  const prefill: Record<string, string> = { plan: rule.label };
  if (result) prefill.deadline = toIsoDate(result.deadline);
  if (amount > 0) prefill.amount = amountBucket(amount);

  return (
    <div className="tool">
      <div className="tool-inputs">
        <fieldset className="segmented" style={{ "--cols": 2 } as React.CSSProperties}>
          <legend>What kind of plan denied it?</legend>
          {PLAN_RULES.map((r) => (
            <label key={r.id}>
              <input type="radio" name="plan" value={r.id} checked={plan === r.id} onChange={() => setPlan(r.id)} />
              <span>{r.label}</span>
            </label>
          ))}
        </fieldset>
        <p className="range-hint" style={{ marginBottom: 22 }}>
          {rule.rule}{" "}
          {rule.source && (
            <>
              Source:{" "}
              <a href={rule.source.url} target="_blank" rel="noopener">{rule.source.name}</a>.
            </>
          )}
        </p>

        <div className="field date-field">
          <label htmlFor={dateId}>Date on the denial letter</label>
          <input
            id={dateId}
            type="date"
            value={letterDate}
            max={maxDate}
            aria-invalid={futureDate ? true : undefined}
            aria-describedby={`${dateId}-hint`}
            onChange={(e) => setLetterDate(e.target.value)}
          />
          {futureDate ? (
            <p className="error" id={`${dateId}-hint`}>That date is in the future. Use the date printed on the letter.</p>
          ) : (
            <p className="hint" id={`${dateId}-hint`}>If you got the letter days later, the date on it is the safer one to use.</p>
          )}
        </div>

        <div className="field">
          <label htmlFor={amountId}>Amount denied (optional)</label>
          <div className="money-input">
            <span aria-hidden="true">$</span>
            <input
              id={amountId}
              type="text"
              inputMode="numeric"
              placeholder="12,000"
              value={amountText}
              onChange={(e) => setAmountText(e.target.value)}
            />
          </div>
          <p className="hint">The bill, or a year of the therapy or drug that was denied.</p>
        </div>
      </div>

      <div className="tool-output" aria-live="polite">
        {!result || !level ? (
          <p className="result-empty">Enter the date on your letter to see your deadline.</p>
        ) : (
          <>
            <span className="status-pill" data-level={level}>
              <LevelIcon level={level} />
              {LEVEL_TEXT[level]}
            </span>
            {level === "past" ? (
              <>
                <p className="countdown">
                  <strong>{Math.abs(result.daysLeft)}</strong>
                  <span>{Math.abs(result.daysLeft) === 1 ? "day" : "days"} past</span>
                </p>
                <p className="deadline-date">The usual deadline was {formatLongDate(result.deadline)}.</p>
                <p className="small-print">
                  There may still be options, depending on your plan and what happened. Send it to us and we’ll check.
                </p>
              </>
            ) : (
              <>
                <p className="countdown">
                  <strong>{result.daysLeft}</strong>
                  <span>{result.daysLeft === 1 ? "day left" : "days left"}</span>
                </p>
                <p className="deadline-date">
                  Appeal by <b>{formatLongDate(result.deadline)}</b>
                </p>
                <p className="small-print">
                  Your letter’s own deadline is the one that counts. Check it, since some plans and states allow longer.
                </p>
              </>
            )}

            {amount > 0 && (
              <div className="fee-box">
                {contingency ? (
                  <>
                    <h4>No win, no fee</h4>
                    <p>If we win the full {money(amount)}, our {CONTINGENCY_RATE * 100}% fee is {money(amount * CONTINGENCY_RATE)}. If we lose, you owe nothing.</p>
                    <div className="fee-split">
                      <div>You keep<b>{money(amount * (1 - CONTINGENCY_RATE))}</b></div>
                      <div>Our fee<b>{money(amount * CONTINGENCY_RATE)}</b></div>
                    </div>
                  </>
                ) : (
                  <>
                    <h4>Appeal letter, {money(LETTER_PRICE)}</h4>
                    <p>
                      For denials under {money(PATIENT_CONTINGENCY_MIN)}, we write the letter and you send it. A free appeal
                      tool or a call to your insurer may be enough, and we’ll say so.
                    </p>
                  </>
                )}
              </div>
            )}

            <StartButton audience="patient" prefill={prefill}>
              Start my free case review
            </StartButton>
          </>
        )}
      </div>
    </div>
  );
}
