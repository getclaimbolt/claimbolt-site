"use client";

import { startIntake, type Audience, type Prefill } from "@/lib/startIntake";

type Props = {
  audience: Audience;
  prefill?: Prefill;
  className?: string;
  children: React.ReactNode;
};

/** A link to the intake form that also switches it to the right audience. Works as a plain anchor without JS. */
export default function StartButton({ audience, prefill, className = "btn", children }: Props) {
  return (
    <a
      href="#start"
      className={className}
      onClick={(e) => {
        e.preventDefault();
        startIntake(audience, prefill);
      }}
    >
      {children}
    </a>
  );
}
