import type { Metadata, Viewport } from "next";
import "@fontsource/public-sans/400.css";
import "@fontsource/public-sans/500.css";
import "@fontsource/public-sans/600.css";
import "@fontsource/public-sans/700.css";
import "@fontsource/public-sans/800.css";
import "@fontsource/public-sans/900.css";
import "@fontsource/courier-prime/400.css";
import "@fontsource/courier-prime/700.css";
import "./globals.css";

const description =
  "ClaimBolt writes and runs insurance appeals for therapy and behavioral health practices and for families facing large denials. You pay a share of what we recover, and nothing if we don't.";

export const metadata: Metadata = {
  metadataBase: new URL("https://getclaimbolt.com"),
  title: "ClaimBolt | Insurance appeals for practices and families",
  description,
  openGraph: {
    title: "ClaimBolt | Insurance appeals for practices and families",
    description,
    url: "https://getclaimbolt.com",
    siteName: "ClaimBolt",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#14213D",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
