import Header from "@/components/Header";
import StartButton from "@/components/StartButton";
import RecoveryEstimator from "@/components/RecoveryEstimator";
import DeadlineChecker from "@/components/DeadlineChecker";
import IntakeWizard from "@/components/IntakeWizard";
import {
  CONTINGENCY_RATE,
  DESK_APPEAL_CAP,
  DESK_PRICE,
  LETTER_PRICE,
  PATIENT_CONTINGENCY_MIN,
  money,
} from "@/lib/pricing";

const pct = `${CONTINGENCY_RATE * 100}%`;
const NY_STUDY = "https://www.healthcaredive.com/news/insurance-denials-overturned-appeal-new-york-study-JAMA/817490/";

const FAQS: { q: string; a: string }[] = [
  {
    q: `How is the ${pct} calculated?`,
    a: `It’s ${pct} of the money paid or the bill reduced because of the appeal. If the win is approval for ongoing care, such as weekly therapy or a monthly drug, the fee is based on the first 12 months of approved benefit, as set out in your agreement. If nothing is recovered, you owe nothing.`,
  },
  {
    q: "Practices: do you need access to our billing system?",
    a: "No. We work from the denial letters, remittance advice and records you export to us through a secure link. We prepare each appeal and either submit it as your authorized representative or hand it to your team ready to send, depending on what each payer requires.",
  },
  {
    q: "Practices: which plan should we choose?",
    a: `Recovery suits a backlog or unpredictable volume, since you only pay on results. The appeals desk suits a steady flow of new denials and works out cheaper once you’re recovering more than about ${money(DESK_PRICE / CONTINGENCY_RATE)} a month. The estimator above shows which is cheaper for your numbers.`,
  },
  {
    q: "Can you guarantee a result?",
    a: "No, and nobody honest can. We promise a careful, well-supported appeal filed on time, and that we’ll tell you upfront if we don’t think a case is winnable.",
  },
  {
    q: "My deadline is close. Can you still help?",
    a: "Probably. Put the date in the form. If waiting could seriously harm your health, you can ask for an expedited appeal, which plans have to decide quickly.",
  },
  {
    q: "Are you a law firm?",
    a: "No. ClaimBolt is not a law firm and doesn’t give legal advice. Most insurance appeals are administrative and don’t need a lawyer. If yours does, we’ll tell you.",
  },
];

export default function Home() {
  return (
    <>
      <Header />
      <main id="top">
        <section className="hero" aria-labelledby="hero-title">
          <div className="wrap hero-grid">
            <div>
              <h1 id="hero-title">Insurance said no. That’s rarely the last word.</h1>
              <p className="lede">
                ClaimBolt writes and runs insurance appeals for therapy and behavioral health practices, and for
                families facing large denials. You pay a share of what we recover, and nothing if we don’t.
              </p>
              <div className="paths">
                <a className="path" href="#estimator">
                  <strong>I run a practice</strong>
                  <span>See what your denials are worth</span>
                </a>
                <a className="path" href="#deadline">
                  <strong>I’m a patient or family</strong>
                  <span>Check your appeal deadline</span>
                </a>
              </div>
            </div>
            <figure
              className="letter"
              role="img"
              aria-label="Illustration of an insurance denial letter, stamped denied, then stamped appealed"
            >
              <div className="head">
                <span>Notice of adverse benefit determination</span>
                <span>Page 1 of 3</span>
              </div>
              <p>Service requested: Applied behavior analysis, 25 hours per week</p>
              <p className="reason">Determination: Not medically necessary. Coverage for this service is denied.</p>
              <p>This decision was based on the plan’s clinical criteria. You have the right to appeal.</p>
              <p>
                You must request an appeal within <span className="deadline">180 days</span> of the date of this
                notice.
              </p>
              <span className="stamp denied" aria-hidden="true">DENIED</span>
              <span className="stamp appealed" aria-hidden="true">APPEALED</span>
            </figure>
          </div>
        </section>

        <section className="section ink-band" aria-labelledby="facts-title">
          <div className="wrap">
            <h2 id="facts-title">Most denials are never challenged. The ones that are often get reversed.</h2>
            <div className="facts">
              <div className="fact">
                <p>
                  <b>1 in 5 insured adults</b>said they or a family member were denied doctor-recommended care in the
                  past year.
                </p>
                <small>
                  <a href="https://www.commonwealthfund.org/publications/surveys/2026/jun/how-health-insurance-coverage-denials-affect-americans-2025-affordability-survey" target="_blank" rel="noopener">
                    Commonwealth Fund, June 2026
                  </a>
                </small>
              </div>
              <div className="fact">
                <p>
                  <b>Fewer than 1 in 500</b>denied in-network claims on ACA marketplace plans went to an internal
                  appeal in 2024.
                </p>
                <small>
                  <a href="https://www.moneygeek.com/insurance/health/aca-claim-denial-rates-by-state-and-insurer/" target="_blank" rel="noopener">
                    MoneyGeek analysis of federal data, 2026
                  </a>
                </small>
              </div>
              <div className="fact">
                <p>
                  <b>Almost 53% overturned</b>of appealed denials in New York in 2025, up from 38% in 2019.
                </p>
                <small>
                  <a href={NY_STUDY} target="_blank" rel="noopener">
                    JAMA study via Healthcare Dive, April 2026
                  </a>
                </small>
              </div>
            </div>
          </div>
        </section>

        <section className="section" aria-labelledby="work-title">
          <div className="wrap">
            <h2 id="work-title">Two ways we work</h2>
            <p className="intro">
              Practices send us the denials their team doesn’t have time for. Families send us the one denial that
              can’t be allowed to stand. Either way, we write the appeal, file it, track the deadline and keep pushing
              through every level of review.
            </p>
            <div className="split">
              <article className="side primary" id="practices" aria-labelledby="practices-title">
                <p className="who">For practices</p>
                <h3 id="practices-title" className="side-title">Stop writing off denied claims</h3>
                <p>
                  ABA, behavioral health, therapy and specialty practices lose real revenue to denials that nobody has
                  time to fight. Each denied claim already costs a practice an estimated $25 to $181 in rework (
                  <a href="https://www.aptarro.com/insights/us-healthcare-denial-rates-reimbursement-statistics" target="_blank" rel="noopener">Aptarro, 2026</a>
                  ). Hand us the backlog and the new ones as they come in.
                </p>
                <div className="plans">
                  <div className="plan">
                    <h4>Recovery</h4>
                    <div className="price">{pct}<small>of what’s paid</small></div>
                    <p>We work your denied and aging claims. You pay {pct} of what the payer pays after our appeal. No setup fee, no monthly fee.</p>
                  </div>
                  <div className="plan">
                    <h4>Appeals desk</h4>
                    <div className="price">{money(DESK_PRICE)}<small>per month</small></div>
                    <p>A flat fee for up to {DESK_APPEAL_CAP} appeals a month, plus a monthly report of denial reasons by payer so your team can stop the repeats.</p>
                  </div>
                </div>
                <div className="side-actions">
                  <StartButton audience="practice">Get a free backlog review</StartButton>
                  <a href="#estimator">Estimate your recovery</a>
                </div>
                <p className="note">
                  Send up to 20 denials and we’ll tell you which are worth fighting and roughly what they’re worth. We
                  sign a Business Associate Agreement before we receive any patient information.
                </p>
              </article>

              <article className="side" id="patients" aria-labelledby="patients-title">
                <p className="who">For patients and families</p>
                <h3 id="patients-title" className="side-title">We run the fight for large denials</h3>
                <p>
                  Therapy cut off, a residential stay denied midway, a drug your doctor says you need. When the amount
                  is large, you want one person who owns the whole case, from the first appeal through external review.
                </p>
                <div className="plans">
                  <div className="plan">
                    <h4>Full appeal, no win no fee</h4>
                    <div className="price">{pct}<small>of what we recover</small></div>
                    <p>For denials of {money(PATIENT_CONTINGENCY_MIN)} or more. We handle every level, including external review and state complaints. You pay nothing unless coverage is approved or money comes back.</p>
                  </div>
                  <div className="plan">
                    <h4>Appeal letter only</h4>
                    <div className="price">{money(LETTER_PRICE)}<small>one time</small></div>
                    <p>For smaller denials. We write the appeal within 48 hours of getting your documents, and you send it yourself.</p>
                  </div>
                </div>
                <div className="side-actions">
                  <StartButton audience="patient" className="btn ghost">Get a free case review</StartButton>
                  <a href="#deadline">Check your deadline</a>
                </div>
                <p className="note">Not every denial needs us. If a free tool or a call to your insurer would do the job, we’ll say so.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="section band" id="estimator" aria-labelledby="estimator-title">
          <div className="wrap">
            <h2 id="estimator-title">What are your denied claims worth?</h2>
            <p className="intro">
              Move the sliders to match your practice. You’ll see roughly what an appeals program could bring back each
              month and which of our plans costs you less.
            </p>
            <RecoveryEstimator />
          </div>
        </section>

        <section className="section" aria-labelledby="fight-title">
          <div className="wrap">
            <h2 id="fight-title">The denials we take on</h2>
            <p className="intro">
              We focus on the categories where denials are expensive, common and often reversible, so we know the plan
              rules and the arguments that work.
            </p>
            <div className="fight">
              <div><h3>ABA and autism therapy</h3><p>Hours cut or denied as not medically necessary, visit limits, and plans ignoring state autism coverage mandates.</p></div>
              <div><h3>Mental health and substance use care</h3><p>Residential, inpatient and intensive outpatient stays denied or cut short. Federal parity law is often on your side.</p></div>
              <div><h3>Specialty drugs</h3><p>Biologics, GLP-1s and other high-cost drugs denied for step therapy, formulary or off-label reasons.</p></div>
              <div><h3>Prior authorization</h3><p>Surgery, imaging and procedures denied before they happen, including after a failed peer-to-peer review.</p></div>
              <div><h3>Home health</h3><p>Over 78% of appealed home healthcare denials were overturned in the New York study (<a href={NY_STUDY} target="_blank" rel="noopener">Healthcare Dive</a>).</p></div>
              <div><h3>Surprise out-of-network bills</h3><p>Emergency care and out-of-network providers at in-network facilities, where the No Surprises Act may protect you.</p></div>
            </div>
          </div>
        </section>

        <section className="section band" id="deadline" aria-labelledby="deadline-title">
          <div className="wrap">
            <h2 id="deadline-title">How long do you have to appeal?</h2>
            <p className="intro">
              Miss the window and you can lose the right to appeal. Pick your plan type and the date on your letter to
              see your deadline and what we’d charge.
            </p>
            <DeadlineChecker />
          </div>
        </section>

        <section className="section" id="how" aria-labelledby="how-title">
          <div className="wrap">
            <h2 id="how-title">How it works</h2>
            <p className="intro">Same process for a single family or a practice sending twenty claims a month.</p>
            <ol className="steps">
              <li><h3>Tell us about it</h3><p>Use the form below. Documents come later through a secure link, after a BAA for practices.</p></li>
              <li><h3>Free review</h3><p>Within one business day we tell you whether it’s worth fighting, which plan suits you, and what we need.</p></li>
              <li><h3>We write and file</h3><p>The appeal is written within 48 hours of complete documents, then filed for you or handed over ready to send.</p></li>
              <li><h3>We keep pushing</h3><p>We track every deadline, follow up with the plan, and take it to the next level or external review if needed.</p></li>
              <li><h3>You pay when it pays</h3><p>On contingency, you pay only after coverage is approved or payment arrives.</p></li>
            </ol>
          </div>
        </section>

        <section className="section band" aria-labelledby="trust-title">
          <div className="wrap cols">
            <div>
              <h2 id="trust-title">A person, not a chatbot</h2>
              <p>
                ClaimBolt is a small New York company. Every case is read by a person who studies the denial, the plan
                documents and the medical records before writing a word.
              </p>
              <p>
                Free AI appeal tools are a fine start for simple denials. We’re for cases where someone needs to own the
                whole process: the deadlines, the follow-up calls, the second-level appeal and external review.
              </p>
            </div>
            <div>
              <h2 className="h2-small">How we handle your records</h2>
              <ul>
                <li>Practices: a signed Business Associate Agreement before any patient information changes hands.</li>
                <li>Files are stored encrypted, behind multi-factor sign-in, and shared only with the insurer or reviewer handling your appeal.</li>
                <li>We collect only what the appeal needs, and delete your files when the case closes or when you ask.</li>
                <li>We never sell or share your information.</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="section" id="faq" aria-labelledby="faq-title">
          <div className="wrap">
            <h2 id="faq-title">Questions</h2>
            <div className="faq">
              {FAQS.map((f) => (
                <details key={f.q}>
                  <summary>{f.q}</summary>
                  <p>{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className="section band" id="start" aria-labelledby="start-title">
          <div className="wrap intake">
            <div className="intake-copy">
              <h2 id="start-title">Get a free review</h2>
              <p>
                Three short steps. We reply within one business day with an honest answer on whether we can help and
                what it would cost.
              </p>
              <p>
                Prefer email? Write to <a href="mailto:appeals@getclaimbolt.com">appeals@getclaimbolt.com</a>.
              </p>
            </div>
            <IntakeWizard />
          </div>
        </section>
      </main>

      <footer>
        <div className="wrap foot">
          <div>
            <p><strong style={{ color: "#fff" }}>ClaimBolt</strong>, New York</p>
            <p><a href="mailto:appeals@getclaimbolt.com">appeals@getclaimbolt.com</a></p>
          </div>
          <div>
            <p>ClaimBolt is not a law firm and does not provide legal advice.</p>
            <p>Results depend on your plan and your case. No outcome is guaranteed.</p>
            <p>© 2026 ClaimBolt</p>
          </div>
        </div>
      </footer>
    </>
  );
}
