// Single source of truth for prices, so the copy and the calculators always agree.
export const CONTINGENCY_RATE = 0.2;
export const LETTER_PRICE = 99;
export const DESK_PRICE = 1500;
export const DESK_APPEAL_CAP = 20;
export const PATIENT_CONTINGENCY_MIN = 2000;

const usd = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

export function money(n: number): string {
  return usd.format(Math.round(n));
}

/** Round estimates so they don't look more precise than they are. */
export function roughMoney(n: number): string {
  const step = n >= 1000 ? 100 : 10;
  return usd.format(Math.round(n / step) * step);
}

export function amountBucket(n: number): string {
  if (n < 2000) return "Under $2,000";
  if (n <= 10000) return "$2,000 – $10,000";
  if (n <= 50000) return "$10,000 – $50,000";
  return "Over $50,000";
}
