export type Audience = "practice" | "patient";
export type Prefill = Record<string, string>;
export type StartDetail = { audience: Audience; prefill: Prefill };

export const START_EVENT = "claimbolt:start";

/** Open the intake form for an audience, optionally pre-filled, and scroll to it. */
export function startIntake(audience: Audience, prefill: Prefill = {}) {
  window.dispatchEvent(new CustomEvent<StartDetail>(START_EVENT, { detail: { audience, prefill } }));
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.getElementById("start")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
}
