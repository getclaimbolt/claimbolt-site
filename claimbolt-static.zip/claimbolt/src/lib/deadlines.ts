export type PlanId = "employer" | "medicare-advantage" | "medicaid" | "unsure";

export type PlanRule = {
  id: PlanId;
  label: string;
  days: number;
  rule: string;
  source?: { name: string; url: string };
};

// First-level appeal windows. Sources checked October 2026.
export const PLAN_RULES: PlanRule[] = [
  {
    id: "employer",
    label: "Job-based or marketplace plan",
    days: 180,
    rule: "180 days from when you received the denial.",
    source: {
      name: "HealthCare.gov",
      url: "https://www.healthcare.gov/appeal-insurance-company-decision/internal-appeals/",
    },
  },
  {
    id: "medicare-advantage",
    label: "Medicare Advantage",
    days: 65,
    rule: "65 days from the date on the denial notice.",
    source: {
      name: "Medicare.gov",
      url: "https://www.medicare.gov/providers-services/claims-appeals-complaints/appeals/medicare-health-plans",
    },
  },
  {
    id: "medicaid",
    label: "Medicaid managed care",
    days: 60,
    rule: "60 calendar days from the date on the notice.",
    source: {
      name: "42 CFR 438.402",
      url: "https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-C/part-438/subpart-F/section-438.402",
    },
  },
  {
    id: "unsure",
    label: "Not sure",
    days: 60,
    rule: "We used 60 days, the shortest of these windows, to be safe.",
  },
];

const DAY = 24 * 60 * 60 * 1000;

/** Parse a YYYY-MM-DD string as a local calendar date. */
export function parseLocalDate(value: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? null : d;
}

export function toIsoDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function computeDeadline(letterDate: Date, days: number, today: Date) {
  const deadline = new Date(letterDate.getFullYear(), letterDate.getMonth(), letterDate.getDate() + days);
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const daysLeft = Math.round((deadline.getTime() - start.getTime()) / DAY);
  return { deadline, daysLeft };
}

export function formatLongDate(d: Date): string {
  return d.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}
