# ClaimBolt website

Next.js 16 site for getclaimbolt.com, built as a static site so it can run free on GitHub Pages.
Everything interactive (recovery estimator, deadline checker, three-step intake form) runs in the browser.
The form posts straight to Formspree.

Prices live in `src/lib/pricing.ts` and appeal windows in `src/lib/deadlines.ts`. Change them there and the copy and calculators update together.

## Run it on your Mac

```bash
npm install
cp .env.example .env.local   # put your Formspree form URL in it
npm run dev                  # http://localhost:3000
```

Without a Formspree URL, the form tells visitors to email appeals@getclaimbolt.com instead.

## Deploy to GitHub Pages (free)

1. Push this folder to your GitHub repo's `main` branch. The workflow in `.github/workflows/deploy.yml` builds and publishes it on every push.
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. Repo → Settings → Secrets and variables → Actions → Variables tab → add `FORMSPREE_ENDPOINT` with your Formspree form URL.
4. Repo → Settings → Pages → Custom domain: `getclaimbolt.com`, then tick **Enforce HTTPS**. If the old site already used this domain, the DNS records stay as they are.
5. Check the Actions tab for a green run, then load the site.

## Before going live

- The page promises encrypted, MFA-protected storage and deletion when a case closes. Set that up, or edit the copy in `src/app/page.tsx`.
- The form collects basics only, no medical files. Collect denial letters by email reply (Gmail, with Google's HIPAA BAA accepted in the Workspace Admin console).
- Have a BAA template ready; the practice offer promises one.
